<?php
return array(
	//'配置项'=>'配置值'
    //数据库配置
    'DB_TYPE'   =>  'mysql',
    'DB_HOST'   =>  '127.0.0.1',
    'DB_USER'   =>  'root',
    'DB_PWD'    =>  '',
    'DB_NAME'   =>  'tp',
    'DB_PREFIX' =>  'tp_',
);