<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html>
<head>
    <title>Page Title</title>
</head>

<body>

<a href="<?php echo U('Public/logout');?>">Logout</a>

</body>
</html>