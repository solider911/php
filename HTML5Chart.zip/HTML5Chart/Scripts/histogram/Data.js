﻿var jasonData = {
    "title": "2014 各分公司营业额",
    "verticaltitle": "金额（万）",
    "horizontaltitle": "公司",
    "data": [{ "category": "营业额", "datacollection": [{ "title": "广州", "amount": "5000" }, { "title": "上海", "amount": "6000" }, { "title": "北京", "amount": "4000" }, { "title": "杭州", "amount": "1000" }, { "title": "成都", "amount": "1500" }] }]    
};